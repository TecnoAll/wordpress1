<?php
//The very spring and root of honesty and virtue lie in good education.
