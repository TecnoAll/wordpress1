<div class="option-bar form-control-buttons">
    <input type="submit" value="<?php esc_html_e( 'Search', 'inspiry-real-estate' ); ?>" class="form-submit-btn">
</div>