<div class="option-bar col-xs-12 submit-btn-wrapper">
    <input type="submit" value="<?php esc_html_e( 'Search', 'inspiry-real-estate' ); ?>" class="form-submit-btn">
</div>