<div class="option-bar col-xs-12 property-status">
    <select name="status" id="select-status" class="search-select">
        <?php ire_generate_taxonomy_options( 'property-status', esc_html__( 'Property Status', 'inspiry-real-estate' ) ); ?>
    </select>
</div>