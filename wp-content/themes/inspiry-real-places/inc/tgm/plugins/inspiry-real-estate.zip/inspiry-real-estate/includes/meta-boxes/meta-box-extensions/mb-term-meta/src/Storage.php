<?php
class RWMB_Term_Storage extends \RWMB_Base_Storage {
	protected $object_type = 'term';
}
