<div class="option-bar col-xs-12 property-type">
    <select name="type" id="select-property-type" class="search-select">
        <?php ire_generate_taxonomy_options( 'property-type', esc_html__( 'Property Type', 'inspiry-real-estate' ) ); ?>
    </select>
</div>