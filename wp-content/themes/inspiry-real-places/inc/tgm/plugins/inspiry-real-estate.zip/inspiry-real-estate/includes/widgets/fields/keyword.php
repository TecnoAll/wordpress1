<div class="option-bar col-xs-12 property-keyword">
    <input type="text" name="keyword" id="keyword-txt" value="<?php echo isset ( $_GET['keyword'] ) ? $_GET['keyword'] : ''; ?>" placeholder="<?php esc_html_e('Keyword', 'inspiry-real-estate'); ?>" />
</div>