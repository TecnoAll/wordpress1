
<div class="option-bar col-xs-12 property-min-price">
    <select name="min-price" id="select-min-price" class="search-select">
        <?php ire_minimum_prices_options(); ?>
    </select>
</div>