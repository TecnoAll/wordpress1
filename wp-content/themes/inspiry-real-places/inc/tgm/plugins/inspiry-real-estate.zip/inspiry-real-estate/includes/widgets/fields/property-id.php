<div class="option-bar col-xs-12 property-id">
    <input type="text" name="property-id" id="property-id-txt" value="<?php echo isset($_GET['property-id'])?$_GET['property-id']:''; ?>" placeholder="<?php esc_html_e('Property ID', 'inspiry-real-estate'); ?>" />
</div>