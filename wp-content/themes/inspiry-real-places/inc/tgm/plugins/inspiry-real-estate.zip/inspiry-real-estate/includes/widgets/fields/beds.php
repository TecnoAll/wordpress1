<div class="option-bar col-xs-12 property-bedrooms">
    <select name="bedrooms" id="select-bedrooms" class="search-select">
        <?php ire_number_options( 'bedrooms', esc_html__( 'Min Beds (Any)', 'inspiry-real-estate' ) ) ?>
    </select>
</div>