<div class="option-bar col-xs-12 property-bathrooms">
    <select name="bathrooms" id="select-bathrooms" class="search-select">
        <?php ire_number_options( 'bathrooms', esc_html__( 'Min Baths (Any)', 'inspiry-real-estate' ) ) ?>
    </select>
</div>